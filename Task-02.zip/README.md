Task 02 – Customer Segmentation using K-Means Clustering

🎯 Problem Statement
Group retail store customers into clusters based on their:
- Annual Income (k$)
- Spending Score (1-100)

 📁 Dataset
[Mall Customers - Kaggle](https://www.kaggle.com/datasets/vjchoudhary7/customer-segmentation-tutorial-in-python)

 🛠️ Tools Used
- Python
- Pandas, NumPy
- scikit-learn (KMeans)
- Matplotlib, Seaborn

 📈 Method
- Applied KMeans clustering after feature scaling
- Used Elbow Method to determine optimal clusters (k=5)

 📊 Output
Color-coded scatter plot showing customer segments by income and spending
