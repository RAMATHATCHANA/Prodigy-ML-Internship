Task 01 – House Price Prediction using Linear Regression

🎯 Problem Statement
Predict house prices based on:
- Square Footage (`GrLivArea`)
- Number of Bedrooms (`BedroomAbvGr`)
- Number of Bathrooms (`FullBath`)

📁 Dataset
[House Prices - Advanced Regression (Kaggle)](https://www.kaggle.com/c/house-prices-advanced-regression-techniques/data)

🛠️ Tools Used
- Python
- Pandas, NumPy
- scikit-learn
- Matplotlib, Seaborn

📈 Model
Linear Regression trained on selected features with:
- **R² Score:** ~0.63
- **MSE:** 2806426667.24

📊 Output
Scatter plot comparing actual vs predicted sale prices