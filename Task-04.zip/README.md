# 🍱 Task 5 – Food Calorie Estimation
Predict the calories per 100g of food items using a Linear Regression model based on encoded food names.

---

## 📁 Dataset

The dataset contains:

* `FoodItem`: Name of the food (e.g., "Paneer Tikka")
* `Cals_per100grams`: Calorie values (e.g., "282 cal")

> ⚠️ The calories column may have string values like `"282 cal"` which need to be cleaned.

---

## ✅ Steps Performed

### 1. 🔍 Data Preprocessing

* Removed `'cal'` and extracted numeric part using regex:

  ```python
  df['Cals_per100grams'] = df['Cals_per100grams'].str.extract(r'(\d+)').astype(float)
  ```
* Converted `FoodItem` into numeric labels using:

  ```python
  df['Food_ID'] = df['FoodItem'].astype('category').cat.codes
  ```

### 2. ✂️ Train-Test Split

```python
from sklearn.model_selection import train_test_split
X = df[['Food_ID']]
y = df['Cals_per100grams']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
```

### 3. 🧠 Model Training

```python
from sklearn.linear_model import LinearRegression
model = LinearRegression()
model.fit(X_train, y_train)
```

### 4. 📈 Evaluation

```python
from sklearn.metrics import r2_score, mean_squared_error
y_pred = model.predict(X_test)
print("R²:", r2_score(y_test, y_pred))
print("MSE:", mean_squared_error(y_test, y_pred))
```

---

## 🛠 Libraries Used

```bash
pandas
numpy
scikit-learn
```

---

## 📌 Output Example

```plaintext
R²: 0.915
MSE: 22.67
```
