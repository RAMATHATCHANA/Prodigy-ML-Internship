# ✋ Hand Gesture Recognition using CNN

## 📌 Project Title:
**Hand Gesture Recognition using Convolutional Neural Networks (CNN)**

## 🎯 Objective:
To build a deep learning model that can classify different hand gestures (`Peace`, `ThumbsUp`, `Stop`) using a custom-created image dataset and a CNN model.

---

## 📁 Dataset Used:
- **Mock Dataset** with 3 gesture classes:
  - `Peace`
  - `ThumbsUp`
  - `Stop`
- 10 synthetic images per class created using `numpy` and `PIL`

---

## ⚙️ Technologies Used:
- Python
- TensorFlow / Keras
- NumPy
- Matplotlib
- PIL (Python Imaging Library)
- Jupyter Notebook

---

## 🧠 Model Architecture:
- CNN with:
  - Conv2D → MaxPooling → Dropout
  - Conv2D → MaxPooling → Dropout
  - Flatten → Dense → Dropout
  - Output Layer: Softmax activation

---

## 📈 Results:
- Trained on 30 images (10 per gesture)
- Accuracy: Varies due to mock data (used for demonstration)
- Model saved as: `hand_gesture_model.h5`

---

## 🚀 Steps to Run:
1. Clone the repository or navigate to `task-04-hand-gesture-recognition`.
2. Run `hand_gesture_cnn.ipynb` in Jupyter Notebook.
3. The notebook:
   - Generates synthetic data
   - Builds & trains the CNN
   - Evaluates model
   - Saves model
   - Tests a prediction

---

## 📦 Output:
```bash
Model saved as hand_gesture_model.h5
Predicted Gesture: Peace
